# Project Name
Smart Attendance System with Face Recognition

## Introduction
It is the Smart Attendance System with Face Recognition. It is also an alternative to the physical attendance register. 

## Description
A concise and clear description of what this project does and the problem it solves. Provide context for why this project exists and its primary goals.

## Table of Contents
- Features (#features)
- Getting Started (#getting-started)
  - Prerequisites (#prerequisites)
  - Installation (#installation)
- Usage (#usage)
- Configuration (#configuration)
- Contributing (#contributing)
- License (#license)

## Features
- **Feature 1**: Real-Time Face Recognition
- **Feature 2**: Attendance Tracking
- **Feature 3**: Automated Attendance Marking
- **Feature 4**: Student Details Integration & Updation 
- **Feature 5**: Auto Registration of new students
- **Feature 6**: GUI (Graphical User Interface) Integration
- **Feature 7**: Automatic Excel Exporting
- **Feature 8**: Login & Register Integration for Security


## Getting Started

### Prerequisites
List any requirements or software needed to run the application:
- Python 3.x (https://www.python.org/)
- Libraries of Python
    - SQLite3 (https://www.sqlite.org/download.html)
    - OS Module (https://docs.python.org/3/library/os.html)
    - Time Module (https://docs.python.org/3/library/time.html)
    - Datetime Module (https://docs.python.org/3/library/datetime.html)
    - Numpy (https://numpy.org/)
    - Pillow (https://pillow.readthedocs.io/en/stable/)
    - Face Recognition (https://github.com/ageitgey/face_recognition)
    - Pandas (https://pandas.pydata.org/)
    - PyQt5 (https://pypi.org/project/PyQt5/)
    - Pickle (https://docs.python.org/3/library/pickle.html)
    - OpenCV (https://opencv.org/)
    - Sys (https://docs.python.org/3/library/sys.html)

### Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/username/project-name.git
   cd project-name
   ```
2. Install dependencies:
   ```bash
   # Replace with your project install command
   pip install library_name1 library_name2 ...
   ```
## Usage
 - Educational Institutions (Colleges & Schools)
 - Offices & Companies
 - Hospitals & Clinics
 - Security & Access Control
 - Government Departments
 - Airlines
 - Mobile-Based Attendance

 The program is running in the way
    Start Program
        ↓
    Login/Register
        ↓
    Open GUI
        ↓
    Start Camera
        ↓
    Capture Frame
        ↓
    Detect Face
        ↓
    Encode Face
        ↓
    Match with Database
        ↓
    IF matched → Mark Attendance
    ELSE → Register New User
        ↓
    Update Database
        ↓
    Display in UI
        ↓
    Repeat

## Configuration

  -  APPLICATION SETTINGS
        - APP_NAME=FaceRecognitionAttendance
        - DEBUG=True

  -  DATABASE CONFIGURATION
        - DB_NAME=attendance.db
        - DB_PATH=attendance.db

  -  DATASET & ENCODINGS
        - DATASET_PATH=Saurabh_fixed
        - ENCODINGS_PATH=encodings.pickle


## Contributing
1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License
Distributed under the MIT License. See `LICENSE` for more information.

## Contact
Project Link: https://github.com/PythonDeveloper66/student-attendance-system-with-face_recognition.git
