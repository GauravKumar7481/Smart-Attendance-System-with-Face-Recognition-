import sys
from PyQt5.QtWidgets import *
from database import register_user,login_user

class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Teacher Login")
        self.setGeometry(500, 400, 500, 300)
        self.username = QLineEdit()
        self.username.setPlaceholderText("Username")
        self.password = QLineEdit()
        self.password.setPlaceholderText("Password")
        self.password.setEchoMode(QLineEdit.Password)
        self.login_btn = QPushButton("Login")
        self.register_btn = QPushButton("Register")
        layout = QVBoxLayout()
        layout.addWidget(self.username)
        layout.addWidget(self.password)
        layout.addWidget(self.login_btn)
        layout.addWidget(self.register_btn)
        self.setLayout(layout)
        self.login_btn.clicked.connect(self.login)
        self.register_btn.clicked.connect(self.register)
    def login(self):
        user = self.username.text()
        pwd = self.password.text()
        if login_user(user,pwd):
            QMessageBox.information(self, "Success", "Login Successful")
            self.open_main()
        else:
            QMessageBox.warning(self, "Error", "Invalid Credentials")
    def register(self):
        user = self.username.text()
        pwd = self.password.text()
        if user and pwd:
            if register_user(user, pwd):
                QMessageBox.information(self, "Success", "Registered Successfully")
                self.open_main()
            else:
                QMessageBox.warning(self, "Error", "Registration failed. Username may already exist.")
        else:
            QMessageBox.warning(self, "Error", "Enter details")
    def open_main(self):
        from app import FaceRecognitionApp
        self.main = FaceRecognitionApp()
        self.main.show()
        self.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LoginWindow()
    window.show()
    sys.exit(app.exec_())
