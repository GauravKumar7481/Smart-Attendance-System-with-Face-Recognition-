import sys
import os
import sqlite3
import pickle
import cv2
import face_recognition
from PyQt5.QtWidgets import QApplication, QLabel, QPushButton, QVBoxLayout, QWidget, QHBoxLayout, QDateEdit, QTableWidget, QTableWidgetItem, QInputDialog
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import QTimer,QDate
import pandas as pd
from database import mark_attendance

# Load encodings
with open("encodings.pickle", "rb") as f:
    data = pickle.load(f)
known_encodings = data["encodings"]
known_names = data["names"]
known_studentRoll= data["studentRoll"]
class FaceRecognitionApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Face Recognition Attendance System")
        self.setGeometry(200, 100, 900, 600)
        self.image_label = QLabel(self)
        self.image_label.setFixedSize(800, 300)
        self.start_btn = QPushButton("Start Camera")
        self.stop_btn = QPushButton("Stop Camera")
        layout = QVBoxLayout()
        layout.addWidget(self.image_label)
        camera_controls_layout = QHBoxLayout()
        camera_controls_layout.addWidget(self.start_btn)
        camera_controls_layout.addWidget(self.stop_btn)
        layout.addLayout(camera_controls_layout)
        # Date filter
        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        self.view_date_btn = QPushButton("View for Date")
        self.show_all_btn = QPushButton("Show All")
        date_filter_layout = QHBoxLayout()
        date_filter_layout.addWidget(QLabel("Select Date:"))
        date_filter_layout.addWidget(self.date_edit)
        date_filter_layout.addWidget(self.view_date_btn)
        date_filter_layout.addWidget(self.show_all_btn)
        layout.addLayout(date_filter_layout)
        self.setLayout(layout)
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.cap = None
        self.start_btn.clicked.connect(self.start_camera)
        self.stop_btn.clicked.connect(self.stop_camera)
        self.view_date_btn.clicked.connect(self.view_attendance_by_date)
        self.show_all_btn.clicked.connect(self.load_attendance_table)
        self.table = QTableWidget()
        layout.addWidget(self.table)
        self.export_btn = QPushButton("Export to Excel")
        self.export_btn.clicked.connect(self.export_to_excel)
        layout.addWidget(self.export_btn)
        self.load_attendance_table()
    def start_camera(self):
        self.cap = cv2.VideoCapture(0)
        self.timer.start(10)
    def stop_camera(self):
        self.timer.stop()
    def view_attendance_by_date(self):
        """View attendance records for the selected date."""
        selected_date = self.date_edit.date().toString("yyyy-MM-dd")
        self.load_attendance_table(date=selected_date)
    def load_attendance_table(self, date=None):
        """Load and display attendance records in the table, optionally filtered by date."""
        conn = sqlite3.connect("attendance.db")
        cursor = conn.cursor()
        if date:
            cursor.execute("SELECT * FROM attendance WHERE date=?", (date,))
        else:
            cursor.execute("SELECT * FROM attendance")
        records = cursor.fetchall()
        print(records)
        self.table.setRowCount(len(records))
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["ID", "Name", "StuentRoll", "Date", "Time"])
        for row_idx, row in enumerate(records):
            for col_idx, value in enumerate(row):
                self.table.setItem(row_idx, col_idx, QTableWidgetItem(str(value)))
        conn.close()
    def update_frame(self):
        if self.cap is None:
            return
        ret, frame = self.cap.read()
        if not ret:
            return
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        boxes = face_recognition.face_locations(rgb)
        encodings = face_recognition.face_encodings(rgb, boxes)
        for encoding, box in zip(encodings, boxes):
            matches = face_recognition.compare_faces(
                known_encodings, encoding, tolerance=0.45
            )
            if True in matches:
                name = known_names[matches.index(True)]
                studentRoll=known_studentRoll[matches.index(True)]
                mark_attendance(name,studentRoll)
                self.load_attendance_table()
            else:
                name, ok = QInputDialog.getText(
                    self, "New Person Detected", "Enter Name: "
                )
                if ok and name.strip():
                    studentRoll, ok1 = QInputDialog.getInt(
                        self, "New Person Detected", "Enter Roll Number: "
                    )
                    if ok1:                   
                        folder = f"Saurabh_fixed/{name}"
                        os.makedirs(folder, exist_ok=True)
                        img_path = f"{folder}/{name}_{studentRoll}.jpg"
                        cv2.imwrite(img_path, frame)
                        print(f"📸 Saved new face for {name}")
                        # Save attendance immediately
                        mark_attendance(name, studentRoll)
                        self.load_attendance_table()
                        # Re-encode faces
                        import subprocess
                        subprocess.run(["python", "encode_faces.py"])
                        # Reload encodings
                        with open("encodings.pickle", "rb") as f:
                            data = pickle.load(f)
                            known_encodings[:] = data["encodings"]
                            known_names[:] = data["names"]
                            known_studentRoll[:] = data["studentRoll"]
            top, right, bottom, left = box
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_per_line = ch * w
        qt_img = QImage(rgb.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.image_label.setPixmap(QPixmap.fromImage(qt_img))
    def export_to_excel(self):
        conn=sqlite3.connect("attendance.db")
        df=pd.read_sql_query("SELECT * FROM attendance",conn)
        df.to_excel("attendance.xlsx",sheet_name="Attendance")
        print("✅ Attendance exported to attendance.xlsx")
        conn.close()
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FaceRecognitionApp()
    window.show()
    sys.exit(app.exec_())
