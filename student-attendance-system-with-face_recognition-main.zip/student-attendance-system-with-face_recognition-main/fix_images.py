from PIL import Image
import os

input_folder = "dataset/Saurabh"
output_folder = "dataset/Saurabh_fixed"

os.makedirs(output_folder, exist_ok=True)

for filename in os.listdir(input_folder):
    path = os.path.join(input_folder, filename)

    try:
        img = Image.open(path)

        # Convert to RGB (8-bit)
        img = img.convert("RGB")

        new_path = os.path.join(output_folder, filename.split('.')[0] + ".jpg")
        img.save(new_path, "JPEG")

        print(f"✅ Fixed: {filename}")

    except Exception as e:
        print(f"❌ Failed: {filename} -> {e}")
