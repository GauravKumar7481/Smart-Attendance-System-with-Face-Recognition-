import sqlite3
from datetime import datetime
def create_db():
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            studentRoll INTEGER,
            date TEXT,
            time TEXT
        )
    """)
    conn.commit()
    conn.close()
def mark_attendance(name, studentRoll):
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()
    date = datetime.now().strftime("%Y-%m-%d")
    time = datetime.now().strftime("%H:%M:%S")
    cursor.execute("""
        SELECT * FROM attendance WHERE name=? AND date=?
    """, (name, date))
    if cursor.fetchone() is None:
        cursor.execute("""
            INSERT INTO attendance (name, studentRoll, date, time)
            VALUES (?, ?, ?, ?)
        """, (name, studentRoll, date, time))
    else:
        cursor.execute("""
            UPDATE attendance SET time=? WHERE name=? AND date=?
        """, (time, name, date))
    conn.commit()
    conn.close()
def create_user_table():
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE,
            password TEXT
        )
    """)
    conn.commit()
    conn.close()
create_user_table()
def register_user(username,password):
    conn=sqlite3.connect("attendance.db")
    cursor=conn.cursor()
    success = False
    try:    
        print("Welcome to you..! You are a new Professor/Teacher..!")
        cursor.execute(""" 
            INSERT INTO users (username,password)
            VALUES (?,?)
        """,(username,password))
        conn.commit()
        success = True
    except:
        print("Username already exists")
    conn.close()
    return success
def login_user(username,password):
    conn = sqlite3.connect("attendance.db")
    cursor = conn.cursor()
    cursor.execute("""
            SELECT * FROM users 
            WHERE username=? AND password=?
        """, (username,password))
    user = cursor.fetchone()
    conn.close()
    return user

create_db()
