import pickle
import os
import face_recognition
from PIL import Image
import numpy as np
import re

dataset_path = "Saurabh_fixed" # Path to dataset folder
known_encodings = []
known_names = []
known_Student_Roll=[]

for person_name in os.listdir(dataset_path):
    person_folder = os.path.join(dataset_path, person_name)

    if not os.path.isdir(person_folder):
        continue

    for image_name in os.listdir(person_folder):
        image_path = os.path.join(person_folder, image_name)
        basename=os.path.basename(image_path)
        Roll=re.search(r'\d+',image_path).group()
        studentRoll=int(Roll)

        try:
            # Open image and convert to RGB
            image = Image.open(image_path)
            image_np = np.array(image)

            encodings = face_recognition.face_encodings(image_np)

            if encodings:
                known_encodings.append(encodings[0])
                known_names.append(person_name)
                known_Student_Roll.append(studentRoll)
                print(f"✅ Encoded: {person_name} - {image_name}")
            else:
                print(f"⚠️ No face found in {image_name}")

        except Exception as e:
            print(f"❌ Error processing {image_name}: {e}")

data = {
    "encodings": known_encodings,
    "names": known_names,
    "studentRoll": known_Student_Roll
}

with open("encodings.pickle", "wb") as f:
    pickle.dump(data, f)

print("✅ Face encodings completed successfully.")
